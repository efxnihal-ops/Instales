package com.instaless.app.domain

import org.junit.Assert.assertEquals
import org.junit.Test

class ScreenClassifierTest {

    @Test
    fun storyViewerWinsOverEverythingElse() {
        val s = ScreenSignals(storyViewer = true, tabBarVisible = true, selectedTab = InstagramTab.Reels, clipsViewer = true)
        assertEquals(ScreenKind.Stories, ScreenClassifier.classify(s))
    }

    @Test
    fun messagesScreenIsRecognised() {
        assertEquals(ScreenKind.DirectMessages, ScreenClassifier.classify(ScreenSignals(directScreen = true)))
    }

    @Test
    fun reelsTabAndReelsViewerAreReels() {
        val tab = ScreenSignals(tabBarVisible = true, selectedTab = InstagramTab.Reels)
        val viewer = ScreenSignals(clipsViewer = true)
        assertEquals(ScreenKind.Reels, ScreenClassifier.classify(tab))
        assertEquals(ScreenKind.Reels, ScreenClassifier.classify(viewer))
    }

    @Test
    fun exploreTabIsExplore() {
        val s = ScreenSignals(tabBarVisible = true, selectedTab = InstagramTab.Explore)
        assertEquals(ScreenKind.Explore, ScreenClassifier.classify(s))
    }

    @Test
    fun homeTabNeedsFeedEvidence() {
        val withFeed = ScreenSignals(tabBarVisible = true, selectedTab = InstagramTab.Home, feedEvidence = true)
        val withoutFeed = ScreenSignals(tabBarVisible = true, selectedTab = InstagramTab.Home)
        assertEquals(ScreenKind.HomeFeed, ScreenClassifier.classify(withFeed))
        assertEquals(ScreenKind.Unknown, ScreenClassifier.classify(withoutFeed))
    }

    @Test
    fun unrecognisedScreensAreUnknown() {
        assertEquals(ScreenKind.Unknown, ScreenClassifier.classify(ScreenSignals()))
        val profile = ScreenSignals(tabBarVisible = true, selectedTab = InstagramTab.Other)
        assertEquals(ScreenKind.Unknown, ScreenClassifier.classify(profile))
    }
}
