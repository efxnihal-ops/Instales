package com.instaless.app.domain

import org.junit.Assert.assertEquals
import org.junit.Test

class BlockPolicyTest {

    private val allOn = AppSettings()

    @Test
    fun messagesStoriesAndUnknownAreNeverBlocked() {
        listOf(ScreenKind.DirectMessages, ScreenKind.Stories, ScreenKind.Unknown).forEach { kind ->
            assertEquals(OverlayMode.None, BlockPolicy.decide(kind, allOn).mode)
        }
    }

    @Test
    fun reelsAndExploreGetFullCoverAndFeedGetsPartialCover() {
        assertEquals(OverlayMode.Full, BlockPolicy.decide(ScreenKind.Reels, allOn).mode)
        assertEquals(OverlayMode.Full, BlockPolicy.decide(ScreenKind.Explore, allOn).mode)
        assertEquals(OverlayMode.BelowStories, BlockPolicy.decide(ScreenKind.HomeFeed, allOn).mode)
    }

    @Test
    fun protectionOffBlocksNothing() {
        val off = allOn.copy(protectionEnabled = false)
        ScreenKind.entries.forEach { kind ->
            assertEquals(OverlayMode.None, BlockPolicy.decide(kind, off).mode)
        }
    }

    @Test
    fun individualSwitchesAreRespected() {
        val noReels = allOn.copy(blockReels = false)
        assertEquals(OverlayMode.None, BlockPolicy.decide(ScreenKind.Reels, noReels).mode)
        assertEquals(OverlayMode.Full, BlockPolicy.decide(ScreenKind.Explore, noReels).mode)
    }

    @Test
    fun dashboardStatusMatchesPolicy() {
        assertEquals(SectionStatus.Allowed, statusFor(InstagramSection.DirectMessages, allOn, true))
        assertEquals(SectionStatus.Blocked, statusFor(InstagramSection.Reels, allOn, true))
        assertEquals(SectionStatus.NotActive, statusFor(InstagramSection.Reels, allOn, false))
        assertEquals(SectionStatus.Paused, statusFor(InstagramSection.Reels, allOn.copy(protectionEnabled = false), true))
    }
}
