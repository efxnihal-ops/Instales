package com.instaless.app.domain

enum class OverlayMode { None, Full, BelowStories }

data class BlockDecision(val mode: OverlayMode, val section: InstagramSection?) {
    companion object {
        val Allow = BlockDecision(OverlayMode.None, null)
    }
}

object BlockPolicy {
    /** DMs, Stories and Unknown screens always return Allow, whatever the settings are. */
    fun decide(kind: ScreenKind, settings: AppSettings): BlockDecision {
        if (!settings.protectionEnabled) return BlockDecision.Allow
        return when (kind) {
            ScreenKind.Reels ->
                if (settings.blockReels) BlockDecision(OverlayMode.Full, InstagramSection.Reels) else BlockDecision.Allow
            ScreenKind.Explore ->
                if (settings.blockExplore) BlockDecision(OverlayMode.Full, InstagramSection.Explore) else BlockDecision.Allow
            ScreenKind.HomeFeed ->
                if (settings.blockHomeFeed) BlockDecision(OverlayMode.BelowStories, InstagramSection.HomeFeed) else BlockDecision.Allow
            ScreenKind.DirectMessages, ScreenKind.Stories, ScreenKind.Unknown -> BlockDecision.Allow
        }
    }
}
