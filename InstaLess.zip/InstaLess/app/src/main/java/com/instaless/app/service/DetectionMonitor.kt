package com.instaless.app.service

import com.instaless.app.domain.ScreenKind
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class DetectionReport(val kind: ScreenKind, val summary: String)

/**
 * Keeps only the latest detection result, in memory, so Settings can show a
 * "Detection check". Contains screen type and signal names only. Never saved.
 */
object DetectionMonitor {
    private val _last = MutableStateFlow<DetectionReport?>(null)
    val last: StateFlow<DetectionReport?> = _last

    fun report(kind: ScreenKind, summary: String) {
        _last.value = DetectionReport(kind, summary)
    }
}
