package com.instaless.app.ui.dashboard

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.instaless.app.domain.InstagramSection
import com.instaless.app.domain.statusFor
import com.instaless.app.ui.AppUiState
import com.instaless.app.ui.components.LogoMark
import com.instaless.app.ui.components.StatusPill
import com.instaless.app.ui.components.SurfaceCard

@Composable
fun DashboardScreen(
    state: AppUiState,
    onProtectionChange: (Boolean) -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        DashboardHeader()
        ProtectionCard(state = state, onToggle = onProtectionChange)
        AccessibilityCard(
            serviceEnabled = state.serviceEnabled,
            onOpenSettings = onOpenAccessibilitySettings,
        )
        SectionStatusCard(state = state)
    }
}

@Composable
private fun DashboardHeader() {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        LogoMark()
        Column {
            Text("InstaLess", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Your messages and Stories stay. The scrolling goes.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ProtectionCard(state: AppUiState, onToggle: (Boolean) -> Unit) {
    val enabled = state.settings.protectionEnabled
    val container by animateColorAsState(
        targetValue = if (enabled) MaterialTheme.colorScheme.primaryContainer
        else MaterialTheme.colorScheme.surfaceVariant,
        animationSpec = tween(300),
        label = "protectionContainer",
    )
    val subtitle = when {
        !enabled -> "Instagram works as usual."
        !state.serviceEnabled -> "Turn on accessibility access below to start blocking."
        else -> "Blocking is active whenever you use Instagram."
    }
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = container,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .toggleable(value = enabled, role = Role.Switch, onValueChange = onToggle)
                .padding(24.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    if (enabled) "Protection is on" else "Protection is off",
                    style = MaterialTheme.typography.titleLarge,
                )
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(checked = enabled, onCheckedChange = null)
        }
    }
}

@Composable
private fun SectionStatusCard(state: AppUiState) {
    SurfaceCard(modifier = Modifier.fillMaxWidth()) {
        InstagramSection.entries.forEachIndexed { index, section ->
            if (index > 0) {
                HorizontalDivider(
                    modifier = Modifier.padding(horizontal = 20.dp),
                    color = MaterialTheme.colorScheme.outlineVariant,
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(section.title, style = MaterialTheme.typography.titleMedium)
                StatusPill(statusFor(section, state.settings, state.serviceEnabled))
            }
        }
    }
}
