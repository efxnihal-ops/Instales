package com.instaless.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

enum class Route(val path: String, val label: String, val icon: ImageVector) {
    Dashboard("dashboard", "Home", Icons.Filled.Home),
    Settings("settings", "Settings", Icons.Filled.Settings),
    Privacy("privacy", "Privacy", Icons.Filled.Lock),
}
