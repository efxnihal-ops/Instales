package com.instaless.app.domain

enum class ThemeMode { System, Light, Dark }

/** Everything the user can change. Saved on the phone by SettingsRepository. */
data class AppSettings(
    val protectionEnabled: Boolean = true,
    val blockReels: Boolean = true,
    val blockExplore: Boolean = true,
    val blockHomeFeed: Boolean = true,
    val showBackButton: Boolean = true,
    val themeMode: ThemeMode = ThemeMode.System,
)
