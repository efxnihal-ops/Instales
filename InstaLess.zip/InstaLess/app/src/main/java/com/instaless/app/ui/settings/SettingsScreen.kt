package com.instaless.app.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.instaless.app.domain.AppSettings
import com.instaless.app.domain.ScreenKind
import com.instaless.app.domain.ThemeMode
import com.instaless.app.service.DetectionMonitor
import com.instaless.app.ui.AppUiState
import com.instaless.app.ui.components.ScreenColumn
import com.instaless.app.ui.components.SettingRow
import com.instaless.app.ui.components.SurfaceCard

@Composable
fun SettingsScreen(state: AppUiState, onUpdate: ((AppSettings) -> AppSettings) -> Unit) {
    val settings = state.settings
    ScreenColumn(title = "Settings") {
        SurfaceCard(modifier = Modifier.fillMaxWidth()) {
            SettingRow(
                title = "Block Reels",
                subtitle = "Covers the whole screen.",
                checked = settings.blockReels,
                onCheckedChange = { value -> onUpdate { it.copy(blockReels = value) } },
            )
            Divider()
            SettingRow(
                title = "Block Explore",
                subtitle = "Covers the whole screen.",
                checked = settings.blockExplore,
                onCheckedChange = { value -> onUpdate { it.copy(blockExplore = value) } },
            )
            Divider()
            SettingRow(
                title = "Block home feed",
                subtitle = "Covers the feed. Stories and messages stay reachable.",
                checked = settings.blockHomeFeed,
                onCheckedChange = { value -> onUpdate { it.copy(blockHomeFeed = value) } },
            )
        }

        SurfaceCard(modifier = Modifier.fillMaxWidth()) {
            SettingRow(
                title = "Show Go back button",
                subtitle = "On the blocked screen cover.",
                checked = settings.showBackButton,
                onCheckedChange = { value -> onUpdate { it.copy(showBackButton = value) } },
            )
        }

        SurfaceCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text("Appearance", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeMode.entries.forEach { mode ->
                        FilterChip(
                            selected = settings.themeMode == mode,
                            onClick = { onUpdate { it.copy(themeMode = mode) } },
                            label = { Text(mode.name) },
                        )
                    }
                }
            }
        }

        DetectionCheckCard(serviceEnabled = state.serviceEnabled)
    }
}

@Composable
private fun Divider() {
    HorizontalDivider(
        modifier = Modifier.padding(horizontal = 20.dp),
        color = MaterialTheme.colorScheme.outlineVariant,
    )
}

@Composable
private fun DetectionCheckCard(serviceEnabled: Boolean) {
    val report by DetectionMonitor.last.collectAsStateWithLifecycle()
    SurfaceCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text("Detection check", style = MaterialTheme.typography.titleMedium)
            val current = report
            if (!serviceEnabled || current == null) {
                Text(
                    "Open Instagram and move between its tabs. The latest result appears here.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                Text("Last seen: ${kindLabel(current.kind)}", style = MaterialTheme.typography.bodyLarge)
                Text(
                    current.summary,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    "Only the screen type is shown. Nothing is saved.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

private fun kindLabel(kind: ScreenKind): String = when (kind) {
    ScreenKind.DirectMessages -> "Messages (allowed)"
    ScreenKind.Stories -> "Stories (allowed)"
    ScreenKind.Reels -> "Reels"
    ScreenKind.Explore -> "Explore"
    ScreenKind.HomeFeed -> "Home feed"
    ScreenKind.Unknown -> "Other screen (allowed)"
}
