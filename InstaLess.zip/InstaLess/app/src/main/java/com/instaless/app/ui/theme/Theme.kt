package com.instaless.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Colours for the Allowed / Blocked states, which Material's scheme has no slot for. */
@Immutable
data class StatusColors(
    val allowed: Color,
    val allowedContainer: Color,
    val blocked: Color,
    val blockedContainer: Color,
)

private val LightStatus = StatusColors(LightAllowed, LightAllowedContainer, LightBlocked, LightBlockedContainer)
private val DarkStatus = StatusColors(DarkAllowed, DarkAllowedContainer, DarkBlocked, DarkBlockedContainer)

private val LocalStatusColors = staticCompositionLocalOf { LightStatus }

private val LightScheme = lightColorScheme(
    primary = LightAccent,
    onPrimary = Color.White,
    primaryContainer = LightAccentContainer,
    onPrimaryContainer = LightInk,
    background = LightPaper,
    onBackground = LightInk,
    surface = LightSurface,
    onSurface = LightInk,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightInkMuted,
    outline = LightOutline,
    outlineVariant = LightOutline,
    error = LightBlocked,
)

private val DarkScheme = darkColorScheme(
    primary = DarkAccent,
    onPrimary = Color(0xFF12143A),
    primaryContainer = DarkAccentContainer,
    onPrimaryContainer = DarkInk,
    background = DarkPaper,
    onBackground = DarkInk,
    surface = DarkSurface,
    onSurface = DarkInk,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkInkMuted,
    outline = DarkOutline,
    outlineVariant = DarkOutline,
    error = DarkBlocked,
)

object InstaLessTheme {
    val status: StatusColors
        @Composable @ReadOnlyComposable get() = LocalStatusColors.current
}

/** Follows the system light/dark setting. A manual override is added with Settings (Step 5). */
@Composable
fun InstaLessTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    CompositionLocalProvider(LocalStatusColors provides if (darkTheme) DarkStatus else LightStatus) {
        MaterialTheme(
            colorScheme = if (darkTheme) DarkScheme else LightScheme,
            typography = InstaLessTypography,
            shapes = InstaLessShapes,
            content = content,
        )
    }
}
