package com.instaless.app.ui.theme

import androidx.compose.ui.graphics.Color

// Light
val LightPaper = Color(0xFFF3F5FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE9ECF5)
val LightInk = Color(0xFF12162B)
val LightInkMuted = Color(0xFF5B6180)
val LightAccent = Color(0xFF4B44D8)
val LightAccentContainer = Color(0xFFE3E2FB)
val LightOutline = Color(0xFFDCE0EC)
val LightAllowed = Color(0xFF146B50)
val LightAllowedContainer = Color(0xFFDDF3EA)
val LightBlocked = Color(0xFFA82B49)
val LightBlockedContainer = Color(0xFFF9E0E6)

// Dark
val DarkPaper = Color(0xFF0D1020)
val DarkSurface = Color(0xFF161A2E)
val DarkSurfaceVariant = Color(0xFF1F2440)
val DarkInk = Color(0xFFECEEF8)
val DarkInkMuted = Color(0xFF9AA0BD)
val DarkAccent = Color(0xFFA5A8FF)
val DarkAccentContainer = Color(0xFF2A2D63)
val DarkOutline = Color(0xFF2A2F4A)
val DarkAllowed = Color(0xFF5FD3A8)
val DarkAllowedContainer = Color(0xFF153A30)
val DarkBlocked = Color(0xFFFF8DA3)
val DarkBlockedContainer = Color(0xFF3F1A25)
