package com.instaless.app.service

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import com.instaless.app.domain.InstagramTab
import com.instaless.app.domain.ScreenSignals

/**
 * Reads the structure of Instagram's current screen and returns ScreenSignals.
 *
 * Privacy: only view IDs, "selected" flags, screen positions and (for selected
 * bottom-bar items only) a short label are looked at. The label is compared with a
 * few tab names and thrown away. Message text is never read.
 *
 * Battery: one bounded walk (max nodes and depth) per run.
 */
class ScreenScanner {

    fun scan(root: AccessibilityNodeInfo, screenHeightPx: Int): ScreenSignals {
        val acc = Accumulator(screenHeightPx)
        walk(root, 0, acc)
        return acc.build()
    }

    private fun walk(node: AccessibilityNodeInfo, depth: Int, acc: Accumulator) {
        acc.visited++
        acc.inspect(node)
        if (depth >= MAX_DEPTH) return
        val count = node.childCount
        for (i in 0 until count) {
            if (acc.visited >= MAX_NODES) return
            val child = node.getChild(i) ?: continue
            try {
                walk(child, depth + 1, acc)
            } finally {
                recycleNode(child)
            }
        }
    }

    private class Accumulator(private val screenHeight: Int) {
        var visited = 0
        private var storyViewer = false
        private var directScreen = false
        private var clipsViewer = false
        private var tabBarVisible = false
        private var feedEvidence = false
        private var selectedTab: InstagramTab? = null
        private var labelTab: InstagramTab? = null
        private var trayBottom: Int? = null
        private var tabTop: Int? = null
        private val rect = Rect()

        fun inspect(node: AccessibilityNodeInfo) {
            val fullId = node.viewIdResourceName
            var knownTab = false
            if (fullId != null && fullId.startsWith(ID_PREFIX)) {
                knownTab = onId(fullId.substring(ID_PREFIX.length), node)
            }
            if (!knownTab && node.isSelected) {
                onSelectedLabel(node)
            }
        }

        /** Returns true when the id is one of the bottom-bar tabs. */
        private fun onId(id: String, node: AccessibilityNodeInfo): Boolean {
            when {
                id.startsWith("reel_viewer") -> storyViewer = true
                id.startsWith("clips_viewer") -> clipsViewer = true
                id.startsWith("row_thread") || id.startsWith("row_inbox") -> directScreen = true
                id.startsWith("direct_") && !id.endsWith("_tab") && !id.endsWith("_button") -> directScreen = true
                id.startsWith("row_feed_") -> feedEvidence = true
                id.startsWith("reels_tray") -> {
                    feedEvidence = true
                    node.getBoundsInScreen(rect)
                    if (!rect.isEmpty) {
                        trayBottom = maxOf(trayBottom ?: 0, rect.bottom)
                    }
                }
            }
            val tab = TAB_IDS[id] ?: return false
            tabBarVisible = true
            node.getBoundsInScreen(rect)
            if (!rect.isEmpty) {
                tabTop = minOf(tabTop ?: Int.MAX_VALUE, rect.top)
            }
            if (node.isSelected) selectedTab = tab
            return true
        }

        /** Backup strategy when tab IDs are not recognised: a selected item low on the screen. */
        private fun onSelectedLabel(node: AccessibilityNodeInfo) {
            val desc = node.contentDescription?.toString() ?: return
            if (desc.length > 30) return
            node.getBoundsInScreen(rect)
            if (rect.isEmpty || rect.top < screenHeight * BOTTOM_BAR_START) return
            val label = desc.trim().lowercase()
            val tab = when {
                label.startsWith("home") -> InstagramTab.Home
                label.startsWith("search") || label.startsWith("explore") -> InstagramTab.Explore
                label.startsWith("reels") -> InstagramTab.Reels
                label.startsWith("message") || label.startsWith("direct") -> InstagramTab.Messages
                else -> return
            }
            labelTab = tab
            tabTop = minOf(tabTop ?: Int.MAX_VALUE, rect.top)
        }

        fun build(): ScreenSignals {
            var tab = selectedTab
            var visible = tabBarVisible
            if (tab == null && labelTab != null) {
                tab = labelTab
                visible = true
            }
            return ScreenSignals(
                storyViewer = storyViewer,
                directScreen = directScreen,
                clipsViewer = clipsViewer,
                tabBarVisible = visible,
                selectedTab = tab,
                feedEvidence = feedEvidence,
                storyTrayBottom = trayBottom,
                tabBarTop = tabTop,
            )
        }
    }

    companion object {
        const val ID_PREFIX = "com.instagram.android:id/"
        private const val MAX_NODES = 700
        private const val MAX_DEPTH = 40
        private const val BOTTOM_BAR_START = 0.85f

        private val TAB_IDS = mapOf(
            "feed_tab" to InstagramTab.Home,
            "search_tab" to InstagramTab.Explore,
            "clips_tab" to InstagramTab.Reels,
            "direct_tab" to InstagramTab.Messages,
            "inbox_tab" to InstagramTab.Messages,
            "creation_tab" to InstagramTab.Other,
            "profile_tab" to InstagramTab.Other,
        )
    }
}

@Suppress("DEPRECATION")
internal fun recycleNode(node: AccessibilityNodeInfo) {
    node.recycle()
}
