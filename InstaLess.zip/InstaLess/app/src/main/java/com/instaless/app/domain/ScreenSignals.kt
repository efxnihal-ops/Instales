package com.instaless.app.domain

enum class ScreenKind { DirectMessages, Stories, Reels, Explore, HomeFeed, Unknown }

enum class InstagramTab { Home, Explore, Reels, Messages, Other }

/**
 * What the scanner noticed on the current Instagram screen. Contains only yes/no flags,
 * a tab name and two pixel positions. Never any text from the screen.
 */
data class ScreenSignals(
    val storyViewer: Boolean = false,
    val directScreen: Boolean = false,
    val clipsViewer: Boolean = false,
    val tabBarVisible: Boolean = false,
    val selectedTab: InstagramTab? = null,
    val feedEvidence: Boolean = false,
    val storyTrayBottom: Int? = null,
    val tabBarTop: Int? = null,
) {
    fun describe(): String {
        val parts = mutableListOf<String>()
        parts += if (tabBarVisible) "tab bar: yes" else "tab bar: no"
        parts += "selected tab: ${selectedTab?.name ?: "none"}"
        if (storyViewer) parts += "story viewer"
        if (directScreen) parts += "messages screen"
        if (clipsViewer) parts += "reels viewer"
        if (feedEvidence) parts += "feed content"
        return parts.joinToString(", ")
    }
}
