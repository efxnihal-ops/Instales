package com.instaless.app.service

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.instaless.app.R
import com.instaless.app.domain.InstagramSection
import com.instaless.app.domain.OverlayMode
import kotlin.math.abs

/**
 * The cover shown over blocked Instagram screens. Uses an accessibility overlay window,
 * which needs no extra "draw over other apps" permission. Built from plain Views
 * (not Compose) to keep it light and independent of an Activity.
 */
class BlockOverlay(private val context: Context, private val actions: Actions) {

    interface Actions {
        fun onGoToDms()
        fun onGoBack()
    }

    data class Request(
        val mode: OverlayMode,
        val section: InstagramSection?,
        val top: Int,
        val bottom: Int,
        val showBackButton: Boolean,
        val dark: Boolean,
    )

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var view: View? = null
    private var shownKey: String? = null
    private var shownTop = 0
    private var shownBottom = 0
    private var focusRequest: AudioFocusRequest? = null

    fun show(request: Request) {
        val key = "${request.mode}|${request.section}|${request.showBackButton}|${request.dark}"
        val existing = view
        if (existing != null && key == shownKey) {
            val moved = abs(request.top - shownTop) > 8 || abs(request.bottom - shownBottom) > 8
            if (request.mode == OverlayMode.BelowStories && moved) {
                try {
                    windowManager.updateViewLayout(existing, layoutParams(request))
                    shownTop = request.top
                    shownBottom = request.bottom
                } catch (e: RuntimeException) {
                    Log.w(TAG, "Could not move overlay", e)
                }
            }
            return
        }
        hide()
        val newView = buildView(request)
        try {
            windowManager.addView(newView, layoutParams(request))
            view = newView
            shownKey = key
            shownTop = request.top
            shownBottom = request.bottom
        } catch (e: RuntimeException) {
            Log.w(TAG, "Could not show overlay", e)
            return
        }
        if (request.mode == OverlayMode.Full) takeAudioFocus()
    }

    fun hide() {
        val current = view
        if (current != null) {
            try {
                windowManager.removeViewImmediate(current)
            } catch (e: IllegalArgumentException) {
                Log.w(TAG, "Overlay was already removed", e)
            }
        }
        view = null
        shownKey = null
        releaseAudioFocus()
    }

    private fun layoutParams(r: Request): WindowManager.LayoutParams {
        val full = r.mode == OverlayMode.Full
        val height = if (full) ViewGroup.LayoutParams.MATCH_PARENT else (r.bottom - r.top).coerceAtLeast(1)
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            height,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = if (full) 0 else r.top
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    private fun buildView(r: Request): View {
        val background = if (r.dark) 0xFF0D1020.toInt() else 0xFFF3F5FA.toInt()
        val ink = if (r.dark) 0xFFECEEF8.toInt() else 0xFF12162B.toInt()
        val muted = if (r.dark) 0xFF9AA0BD.toInt() else 0xFF5B6180.toInt()
        val accent = if (r.dark) 0xFFA5A8FF.toInt() else 0xFF4B44D8.toInt()
        val onAccent = if (r.dark) 0xFF12143A.toInt() else 0xFFFFFFFF.toInt()
        val (title, body) = messageFor(r.section)

        val root = FrameLayout(context)
        root.setBackgroundColor(background)
        root.isClickable = true

        val column = LinearLayout(context)
        column.orientation = LinearLayout.VERTICAL
        column.gravity = Gravity.CENTER_HORIZONTAL
        column.setPadding(dp(32), dp(24), dp(32), dp(24))

        val logo = ImageView(context)
        logo.setImageResource(R.drawable.ic_logo_mark)
        logo.setColorFilter(onAccent)
        logo.setPadding(dp(14), dp(14), dp(14), dp(14))
        logo.background = rounded(accent, dp(18))
        column.addView(logo, LinearLayout.LayoutParams(dp(60), dp(60)))

        val titleView = TextView(context)
        titleView.text = title
        titleView.setTextColor(ink)
        titleView.textSize = 24f
        titleView.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        titleView.gravity = Gravity.CENTER
        column.addView(titleView, linearParams(top = 24))

        val bodyView = TextView(context)
        bodyView.text = body
        bodyView.setTextColor(muted)
        bodyView.textSize = 15f
        bodyView.gravity = Gravity.CENTER
        bodyView.setLineSpacing(0f, 1.15f)
        column.addView(bodyView, linearParams(top = 8))

        val primary = TextView(context)
        primary.text = "Go to DMs"
        primary.setTextColor(onAccent)
        primary.textSize = 16f
        primary.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        primary.gravity = Gravity.CENTER
        primary.minHeight = dp(52)
        primary.background = rounded(accent, dp(16))
        primary.isClickable = true
        primary.setOnClickListener { actions.onGoToDms() }
        column.addView(primary, LinearLayout.LayoutParams(dp(280), LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(28)
        })

        if (r.showBackButton) {
            val secondary = TextView(context)
            secondary.text = "Go back"
            secondary.setTextColor(accent)
            secondary.textSize = 15f
            secondary.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            secondary.gravity = Gravity.CENTER
            secondary.minHeight = dp(48)
            secondary.isClickable = true
            secondary.setOnClickListener { actions.onGoBack() }
            column.addView(secondary, LinearLayout.LayoutParams(dp(280), LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(8)
            })
        }

        root.addView(
            column,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER,
            ),
        )
        return root
    }

    private fun messageFor(section: InstagramSection?): Pair<String, String> = when (section) {
        InstagramSection.Reels ->
            "Reels are blocked" to "InstaLess is keeping you out of the scroll. Your messages and Stories are still open."
        InstagramSection.Explore ->
            "Explore is blocked" to "Nothing to scroll here. Your messages and Stories are still open."
        InstagramSection.HomeFeed ->
            "The feed is blocked" to "Stories are above and messages are one tap away."
        else ->
            "This screen is blocked" to "Your messages and Stories are still open."
    }

    private fun linearParams(top: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT,
        ).apply { topMargin = dp(top) }

    private fun rounded(color: Int, radiusPx: Int): GradientDrawable {
        val drawable = GradientDrawable()
        drawable.shape = GradientDrawable.RECTANGLE
        drawable.cornerRadius = radiusPx.toFloat()
        drawable.setColor(color)
        return drawable
    }

    private fun dp(value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    /** Best effort: asks other apps to pause so Reels audio does not play behind the cover. */
    private fun takeAudioFocus() {
        if (focusRequest != null) return
        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build(),
            )
            .setOnAudioFocusChangeListener { }
            .build()
        audioManager.requestAudioFocus(request)
        focusRequest = request
    }

    private fun releaseAudioFocus() {
        val request = focusRequest ?: return
        audioManager.abandonAudioFocusRequest(request)
        focusRequest = null
    }

    private companion object {
        const val TAG = "InstaLessOverlay"
    }
}
