package com.instaless.app.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.instaless.app.domain.SectionStatus
import com.instaless.app.ui.theme.InstaLessTheme

@Composable
fun StatusPill(status: SectionStatus) {
    val colors = InstaLessTheme.status
    val scheme = MaterialTheme.colorScheme
    when (status) {
        SectionStatus.Allowed -> Pill("Allowed", colors.allowedContainer, colors.allowed)
        SectionStatus.Blocked -> Pill("Blocked", colors.blockedContainer, colors.blocked)
        SectionStatus.Paused -> Pill("Paused", scheme.surfaceVariant, scheme.onSurfaceVariant)
        SectionStatus.NotActive -> Pill("Not active", scheme.surfaceVariant, scheme.onSurfaceVariant)
    }
}

@Composable
fun OnOffPill(on: Boolean) {
    val colors = InstaLessTheme.status
    val scheme = MaterialTheme.colorScheme
    if (on) {
        Pill("On", colors.allowedContainer, colors.allowed)
    } else {
        Pill("Off", scheme.surfaceVariant, scheme.onSurfaceVariant)
    }
}

@Composable
private fun Pill(label: String, background: Color, foreground: Color) {
    val animatedBackground by animateColorAsState(background, tween(300), label = "pillBackground")
    val animatedForeground by animateColorAsState(foreground, tween(300), label = "pillForeground")
    Text(
        text = label,
        style = MaterialTheme.typography.labelLarge,
        color = animatedForeground,
        modifier = Modifier
            .background(animatedBackground, CircleShape)
            .padding(horizontal = 14.dp, vertical = 6.dp),
    )
}
