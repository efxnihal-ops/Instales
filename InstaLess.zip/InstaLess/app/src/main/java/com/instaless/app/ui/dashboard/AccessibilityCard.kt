package com.instaless.app.ui.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.instaless.app.ui.components.OnOffPill
import com.instaless.app.ui.components.SurfaceCard

@Composable
fun AccessibilityCard(serviceEnabled: Boolean, onOpenSettings: () -> Unit) {
    var showDisclosure by rememberSaveable { mutableStateOf(false) }

    SurfaceCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text("Accessibility access", style = MaterialTheme.typography.titleMedium)
                OnOffPill(on = serviceEnabled)
            }
            if (serviceEnabled) {
                Text(
                    "InstaLess can see which Instagram screen is open, so it can cover the blocked ones.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                TextButton(onClick = onOpenSettings) { Text("Manage in Android settings") }
            } else {
                Text(
                    "InstaLess needs this to tell which Instagram screen is open. Nothing starts until you turn it on yourself.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                SetupSteps()
                Button(
                    onClick = { showDisclosure = true },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Set up") }
            }
        }
    }

    if (showDisclosure) {
        AccessibilityDisclosureDialog(
            onContinue = {
                showDisclosure = false
                onOpenSettings()
            },
            onDismiss = { showDisclosure = false },
        )
    }
}

@Composable
private fun SetupSteps() {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        val style = MaterialTheme.typography.bodyMedium
        Text("1. Tap Set up, then Open settings.", style = style)
        Text("2. Find InstaLess. It may be under Installed apps or Downloaded apps.", style = style)
        Text("3. Turn it on and tap Allow.", style = style)
        Text(
            "Switch greyed out? Open InstaLess in App info, tap the menu at the top right, choose Allow restricted settings, then try again.",
            style = style,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun AccessibilityDisclosureDialog(onContinue: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Before you turn this on") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                DisclosureItem(
                    "Why it is needed",
                    "Android only tells an app which screen is open through its Accessibility feature. InstaLess uses it to spot Reels, Explore and the home feed in Instagram.",
                )
                DisclosureItem(
                    "What it looks at",
                    "Names of screens and buttons, which bottom tab is selected, and where things sit on screen. It does not read message text.",
                )
                DisclosureItem(
                    "What it never collects",
                    "Messages, passwords, photos or anything you type. Nothing is sent anywhere.",
                )
                DisclosureItem(
                    "How to turn it off",
                    "Use the switch on the Home tab, or turn InstaLess off in Android's Accessibility settings at any time.",
                )
            }
        },
        confirmButton = { TextButton(onClick = onContinue) { Text("Open settings") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Not now") } },
    )
}

@Composable
private fun DisclosureItem(heading: String, body: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(heading, style = MaterialTheme.typography.titleMedium)
        Text(
            body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
