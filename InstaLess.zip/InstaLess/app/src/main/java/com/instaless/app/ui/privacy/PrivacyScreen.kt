package com.instaless.app.ui.privacy

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.instaless.app.ui.components.ScreenColumn
import com.instaless.app.ui.components.SurfaceCard

private data class PrivacyItem(val heading: String, val body: String)

private val privacyItems = listOf(
    PrivacyItem(
        "Why InstaLess needs accessibility access",
        "Android only tells an app which screen is open through its Accessibility feature. " +
            "InstaLess uses it to tell whether you are in Instagram's messages, Stories, Reels, Explore or home feed.",
    ),
    PrivacyItem(
        "What it looks at",
        "Names of screens and buttons, which bottom tab is selected, and where things sit on screen. " +
            "It does not read message text. Each check is thrown away after it is used.",
    ),
    PrivacyItem(
        "What it never collects",
        "Your messages, passwords, photos or anything you type. " +
            "InstaLess has no permission to use the internet and never asks for your Instagram login.",
    ),
    PrivacyItem(
        "What is saved on your phone",
        "Only your own switches from Settings. The Detection check in Settings keeps just the latest screen type " +
            "in memory, and it is gone when the app closes.",
    ),
    PrivacyItem(
        "How to turn it off",
        "Switch protection off on the Home tab, or turn InstaLess off in your phone's Accessibility settings. " +
            "InstaLess never turns itself on.",
    ),
)

@Composable
fun PrivacyScreen() {
    ScreenColumn(title = "Privacy") {
        SurfaceCard(modifier = Modifier.fillMaxWidth()) {
            privacyItems.forEachIndexed { index, item ->
                if (index > 0) {
                    HorizontalDivider(
                        modifier = Modifier.padding(horizontal = 20.dp),
                        color = MaterialTheme.colorScheme.outlineVariant,
                    )
                }
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(item.heading, style = MaterialTheme.typography.titleMedium)
                    Text(
                        item.body,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
