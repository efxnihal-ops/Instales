package com.instaless.app.service

import android.content.ComponentName
import android.content.Context
import android.provider.Settings

object AccessibilityStatus {
    /** True when the user has switched InstaLess on in Android's Accessibility settings. */
    fun isServiceEnabled(context: Context): Boolean {
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
        ) ?: return false
        val expected = ComponentName(context, InstaLessService::class.java)
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == expected }
    }
}
