package com.instaless.app.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.instaless.app.domain.AppSettings
import com.instaless.app.ui.AppUiState
import com.instaless.app.ui.dashboard.DashboardScreen
import com.instaless.app.ui.privacy.PrivacyScreen
import com.instaless.app.ui.settings.SettingsScreen

@Composable
fun AppNavHost(
    navController: NavHostController,
    state: AppUiState,
    onUpdateSettings: ((AppSettings) -> AppSettings) -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    NavHost(
        navController = navController,
        startDestination = Route.Dashboard.path,
        modifier = modifier,
        enterTransition = { fadeIn(tween(220)) },
        exitTransition = { fadeOut(tween(140)) },
        popEnterTransition = { fadeIn(tween(220)) },
        popExitTransition = { fadeOut(tween(140)) },
    ) {
        composable(Route.Dashboard.path) {
            DashboardScreen(
                state = state,
                onProtectionChange = { enabled -> onUpdateSettings { it.copy(protectionEnabled = enabled) } },
                onOpenAccessibilitySettings = onOpenAccessibilitySettings,
            )
        }
        composable(Route.Settings.path) { SettingsScreen(state = state, onUpdate = onUpdateSettings) }
        composable(Route.Privacy.path) { PrivacyScreen() }
    }
}
