package com.instaless.app.domain

/**
 * Turns scanner signals into a screen type. Order matters and is deliberately
 * "fail open": anything allowed is checked first, and anything not clearly
 * recognised is Unknown, which is never blocked.
 */
object ScreenClassifier {
    fun classify(s: ScreenSignals): ScreenKind = when {
        s.storyViewer -> ScreenKind.Stories
        s.directScreen -> ScreenKind.DirectMessages
        s.clipsViewer -> ScreenKind.Reels
        s.tabBarVisible && s.selectedTab == InstagramTab.Messages -> ScreenKind.DirectMessages
        s.tabBarVisible && s.selectedTab == InstagramTab.Reels -> ScreenKind.Reels
        s.tabBarVisible && s.selectedTab == InstagramTab.Explore -> ScreenKind.Explore
        s.tabBarVisible && s.selectedTab == InstagramTab.Home && s.feedEvidence -> ScreenKind.HomeFeed
        else -> ScreenKind.Unknown
    }
}
