package com.instaless.app.domain

/** The parts of Instagram InstaLess cares about. */
enum class InstagramSection(val title: String, val isAlwaysAllowed: Boolean) {
    DirectMessages("Direct messages", isAlwaysAllowed = true),
    Stories("Stories", isAlwaysAllowed = true),
    Reels("Reels", isAlwaysAllowed = false),
    Explore("Explore", isAlwaysAllowed = false),
    HomeFeed("Home feed", isAlwaysAllowed = false),
}

enum class SectionStatus { Allowed, Blocked, Paused, NotActive }

private fun isBlockSwitchedOn(section: InstagramSection, settings: AppSettings): Boolean = when (section) {
    InstagramSection.Reels -> settings.blockReels
    InstagramSection.Explore -> settings.blockExplore
    InstagramSection.HomeFeed -> settings.blockHomeFeed
    InstagramSection.DirectMessages, InstagramSection.Stories -> false
}

/** What the dashboard shows for each section. DMs and Stories are never blocked. */
fun statusFor(section: InstagramSection, settings: AppSettings, serviceEnabled: Boolean): SectionStatus = when {
    section.isAlwaysAllowed -> SectionStatus.Allowed
    !isBlockSwitchedOn(section, settings) -> SectionStatus.Allowed
    !settings.protectionEnabled -> SectionStatus.Paused
    !serviceEnabled -> SectionStatus.NotActive
    else -> SectionStatus.Blocked
}
