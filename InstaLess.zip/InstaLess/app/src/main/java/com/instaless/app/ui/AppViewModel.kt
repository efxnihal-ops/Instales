package com.instaless.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.instaless.app.data.SettingsRepository
import com.instaless.app.domain.AppSettings
import com.instaless.app.service.AccessibilityStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AppUiState(
    val settings: AppSettings = AppSettings(),
    val serviceEnabled: Boolean = false,
)

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = SettingsRepository.get(application)
    private val serviceEnabled = MutableStateFlow(AccessibilityStatus.isServiceEnabled(application))

    val uiState: StateFlow<AppUiState> = combine(repository.settings, serviceEnabled) { settings, enabled ->
        AppUiState(settings = settings, serviceEnabled = enabled)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, AppUiState(serviceEnabled = serviceEnabled.value))

    /** Called when the app comes back to the screen, e.g. after the user visits Android settings. */
    fun refreshServiceStatus() {
        serviceEnabled.value = AccessibilityStatus.isServiceEnabled(getApplication())
    }

    fun update(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { repository.update(transform) }
    }
}
