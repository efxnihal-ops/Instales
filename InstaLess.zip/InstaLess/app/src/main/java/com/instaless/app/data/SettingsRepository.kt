package com.instaless.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.instaless.app.domain.AppSettings
import com.instaless.app.domain.ThemeMode
import java.io.IOException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "instaless_settings")

/**
 * Saves settings in a small file on the phone (it survives app restarts and reboots).
 * The app and the accessibility service run in the same process and share this one instance.
 */
class SettingsRepository private constructor(private val appContext: Context) {

    val settings: Flow<AppSettings> = appContext.settingsDataStore.data
        .catch { error ->
            if (error is IOException) emit(emptyPreferences()) else throw error
        }
        .map { prefs -> prefs.toSettings() }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        appContext.settingsDataStore.edit { prefs ->
            val updated = transform(prefs.toSettings())
            prefs[Keys.PROTECTION] = updated.protectionEnabled
            prefs[Keys.BLOCK_REELS] = updated.blockReels
            prefs[Keys.BLOCK_EXPLORE] = updated.blockExplore
            prefs[Keys.BLOCK_HOME_FEED] = updated.blockHomeFeed
            prefs[Keys.SHOW_BACK] = updated.showBackButton
            prefs[Keys.THEME] = updated.themeMode.name
        }
    }

    private object Keys {
        val PROTECTION = booleanPreferencesKey("protection_enabled")
        val BLOCK_REELS = booleanPreferencesKey("block_reels")
        val BLOCK_EXPLORE = booleanPreferencesKey("block_explore")
        val BLOCK_HOME_FEED = booleanPreferencesKey("block_home_feed")
        val SHOW_BACK = booleanPreferencesKey("show_back_button")
        val THEME = stringPreferencesKey("theme_mode")
    }

    private fun Preferences.toSettings(): AppSettings {
        val defaults = AppSettings()
        return AppSettings(
            protectionEnabled = this[Keys.PROTECTION] ?: defaults.protectionEnabled,
            blockReels = this[Keys.BLOCK_REELS] ?: defaults.blockReels,
            blockExplore = this[Keys.BLOCK_EXPLORE] ?: defaults.blockExplore,
            blockHomeFeed = this[Keys.BLOCK_HOME_FEED] ?: defaults.blockHomeFeed,
            showBackButton = this[Keys.SHOW_BACK] ?: defaults.showBackButton,
            themeMode = ThemeMode.entries.firstOrNull { it.name == this[Keys.THEME] } ?: defaults.themeMode,
        )
    }

    companion object {
        @Volatile
        private var instance: SettingsRepository? = null

        fun get(context: Context): SettingsRepository =
            instance ?: synchronized(this) {
                instance ?: SettingsRepository(context.applicationContext).also { instance = it }
            }
    }
}
