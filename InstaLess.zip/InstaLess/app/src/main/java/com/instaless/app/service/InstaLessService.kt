package com.instaless.app.service

import android.accessibilityservice.AccessibilityService
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager
import com.instaless.app.data.SettingsRepository
import com.instaless.app.domain.AppSettings
import com.instaless.app.domain.BlockDecision
import com.instaless.app.domain.BlockPolicy
import com.instaless.app.domain.OverlayMode
import com.instaless.app.domain.ScreenClassifier
import com.instaless.app.domain.ScreenSignals
import com.instaless.app.domain.ThemeMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Watches Instagram and covers Reels, Explore and the home feed.
 *
 * Everything runs on the main thread. To stay light on battery:
 *  - content-change events are only requested while Instagram is on screen and protection is on,
 *  - bursts of events are collapsed into one check every ~150 ms,
 *  - one check is a single bounded walk of the screen (see ScreenScanner).
 */
class InstaLessService : AccessibilityService(), BlockOverlay.Actions {

    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val scanner = ScreenScanner()
    private var overlay: BlockOverlay? = null

    private var settings = AppSettings()
    private var instagramActive = false
    private var evaluatePending = false
    private var suppressUntil = 0L
    private var appliedEventTypes = -1
    private var imePackages: Set<String> = emptySet()

    private val evaluateRunnable = Runnable {
        evaluatePending = false
        evaluate()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        overlay = BlockOverlay(this, this)
        imePackages = loadImePackages()
        instagramActive = isInstagramInFront()
        scope.launch {
            SettingsRepository.get(this@InstaLessService).settings.collect { onSettingsChanged(it) }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !settings.protectionEnabled) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (pkg == INSTAGRAM) {
            if (!instagramActive) setInstagramActive(true)
            scheduleEvaluate()
        } else if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            instagramActive &&
            !isIgnoredPackage(pkg)
        ) {
            // The user moved to another app: stop listening and remove the cover.
            setInstagramActive(false)
            overlay?.hide()
        }
    }

    override fun onInterrupt() {
        overlay?.hide()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        scope.cancel()
        overlay?.hide()
        super.onDestroy()
    }

    // ---- BlockOverlay.Actions ----

    override fun onGoToDms() {
        suppressUntil = SystemClock.uptimeMillis() + SUPPRESS_MS
        overlay?.hide()
        if (!clickInstagramDmButton()) openInstagramInbox()
        handler.postDelayed({ scheduleEvaluate() }, SUPPRESS_MS + 100)
    }

    override fun onGoBack() {
        suppressUntil = SystemClock.uptimeMillis() + SUPPRESS_MS
        overlay?.hide()
        performGlobalAction(GLOBAL_ACTION_BACK)
        handler.postDelayed({ scheduleEvaluate() }, SUPPRESS_MS + 100)
    }

    // ---- Core logic ----

    private fun onSettingsChanged(new: AppSettings) {
        settings = new
        applyEventTypes()
        if (!new.protectionEnabled) {
            overlay?.hide()
        } else if (instagramActive) {
            scheduleEvaluate()
        }
    }

    private fun scheduleEvaluate() {
        if (evaluatePending) return
        evaluatePending = true
        handler.postDelayed(evaluateRunnable, EVALUATE_DELAY_MS)
    }

    private fun evaluate() {
        if (!settings.protectionEnabled || !instagramActive) {
            overlay?.hide()
            return
        }
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString()
        if (pkg != INSTAGRAM) {
            recycleNode(root)
            if (pkg != null && !isIgnoredPackage(pkg)) {
                setInstagramActive(false)
                overlay?.hide()
            }
            return
        }
        val height = resources.displayMetrics.heightPixels
        val signals = try {
            scanner.scan(root, height)
        } finally {
            recycleNode(root)
        }
        val kind = ScreenClassifier.classify(signals)
        DetectionMonitor.report(kind, signals.describe())

        val decision = BlockPolicy.decide(kind, settings)
        if (decision.mode == OverlayMode.None) {
            overlay?.hide()
            return
        }
        if (SystemClock.uptimeMillis() < suppressUntil) return
        showOverlay(decision, signals, height)
    }

    private fun showOverlay(decision: BlockDecision, signals: ScreenSignals, screenHeight: Int) {
        val density = resources.displayMetrics.density
        var top = 0
        var bottom = screenHeight
        if (decision.mode == OverlayMode.BelowStories) {
            // Leave the Stories row and the bottom tab bar uncovered.
            top = signals.storyTrayBottom ?: (112 * density).toInt()
            bottom = signals.tabBarTop ?: (screenHeight - (80 * density).toInt())
            if (bottom - top < (120 * density).toInt()) {
                // Not enough room to cover safely, so do nothing rather than risk blocking Stories.
                overlay?.hide()
                return
            }
        }
        overlay?.show(
            BlockOverlay.Request(
                mode = decision.mode,
                section = decision.section,
                top = top,
                bottom = bottom,
                showBackButton = settings.showBackButton,
                dark = isDark(),
            ),
        )
    }

    private fun isDark(): Boolean = when (settings.themeMode) {
        ThemeMode.Dark -> true
        ThemeMode.Light -> false
        ThemeMode.System ->
            (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    private fun setInstagramActive(active: Boolean) {
        instagramActive = active
        applyEventTypes()
    }

    private fun applyEventTypes() {
        val wanted = when {
            !settings.protectionEnabled -> AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            instagramActive ->
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            else -> AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        }
        if (wanted == appliedEventTypes) return
        val info = serviceInfo ?: return
        info.eventTypes = wanted
        serviceInfo = info
        appliedEventTypes = wanted
    }

    private fun isInstagramInFront(): Boolean {
        val root = rootInActiveWindow ?: return false
        val isInstagram = root.packageName?.toString() == INSTAGRAM
        recycleNode(root)
        return isInstagram
    }

    private fun isIgnoredPackage(pkg: String): Boolean =
        pkg == packageName || pkg == "com.android.systemui" || pkg in imePackages

    private fun loadImePackages(): Set<String> {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        return imm.enabledInputMethodList.map { it.packageName }.toSet()
    }

    // ---- Go to DMs ----

    /** First choice: tap Instagram's own message button if it is on the current screen. */
    private fun clickInstagramDmButton(): Boolean {
        val root = rootInActiveWindow ?: return false
        try {
            for (name in DM_BUTTON_IDS) {
                val nodes = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM:id/$name")
                var clicked = false
                for (node in nodes) {
                    if (!clicked) clicked = clickNodeOrParent(node)
                    recycleNode(node)
                }
                if (clicked) return true
            }
            return false
        } finally {
            recycleNode(root)
        }
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        var steps = 0
        while (current != null && steps < 4) {
            if (current.isClickable && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            current = current.parent
            steps++
        }
        return false
    }

    /** Second choice: open Instagram's message inbox through its own link, then plain Instagram. */
    private fun openInstagramInbox() {
        val deepLink = Intent(Intent.ACTION_VIEW, Uri.parse("instagram://direct_inbox"))
            .setPackage(INSTAGRAM)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(deepLink)
            return
        } catch (e: ActivityNotFoundException) {
            // fall through to the launcher intent
        } catch (e: SecurityException) {
            // fall through to the launcher intent
        }
        val launch = packageManager.getLaunchIntentForPackage(INSTAGRAM) ?: return
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(launch)
        } catch (e: ActivityNotFoundException) {
            // Instagram is not installed or cannot be opened: nothing more to do.
        }
    }

    private companion object {
        const val INSTAGRAM = "com.instagram.android"
        const val EVALUATE_DELAY_MS = 150L
        const val SUPPRESS_MS = 1200L
        val DM_BUTTON_IDS = listOf("action_bar_inbox_button", "direct_tab")
    }
}
