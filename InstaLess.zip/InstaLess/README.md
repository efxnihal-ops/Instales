# InstaLess

Android app that works alongside the original Instagram app. It covers Reels, Explore and the
home feed, and leaves messages (DMs) and Stories open. It uses an Android AccessibilityService,
works fully on the device, has no internet permission and never reads message text.

## Status: written, NOT yet compiled or tested on a phone
See "Known limits" below before relying on it.

## Get the APK (no Android Studio needed)
1. Create a free GitHub account and a new repository.
2. Upload everything from this folder (keep the `.github` folder).
3. Open the repository's **Actions** tab, pick **Build APK**, press **Run workflow**
   (it also runs on every upload).
4. When the run is green, open it and download **InstaLess-debug-apk** at the bottom.
   Unzip it to get `app-debug.apk`.
5. Copy the APK to the phone and install it (Android will ask to allow installing from your file manager/browser).

If the run is red, open it, copy the red error text and send it to be fixed.

## Or build in Android Studio
File > Open > select this folder (JDK 17). If asked about Gradle choose 8.9. Run on a phone.

## Turn it on
1. Open InstaLess, tap **Set up**, read the explanation, tap **Open settings**.
2. Find InstaLess under Accessibility (Installed apps / Downloaded apps), switch it on, tap Allow.
3. If the switch is greyed out: Settings > Apps > InstaLess > menu (top right) > **Allow restricted settings**, then retry.
4. Come back to InstaLess: Accessibility access shows **On**.
5. Open Instagram and use Settings > **Detection check** to confirm it recognises each screen.

## How it works
`ScreenScanner` makes one bounded pass over Instagram's current screen and records only yes/no
signals (tab bar visible, which tab is selected, story viewer, reels viewer, ...).
`ScreenClassifier` turns those into a screen type, `BlockPolicy` decides whether to cover it,
`BlockOverlay` draws the cover. Unknown screens, DMs and Stories are never covered.

## Known limits
- Detection depends on Instagram's internal view names and tab labels, which can change in any update.
  Nothing here has been checked against a live Instagram; use Detection check to see what it recognises.
- Tab labels are matched in English only (view names are language independent).
- Stories and the home feed share one screen, so on Home the cover starts below the Stories row.
- Reels opened from a message (shared reels) are covered too.
- Audio may keep playing under the cover on some phones.
- "Go to DMs" tries Instagram's own message button, then the link `instagram://direct_inbox`.
